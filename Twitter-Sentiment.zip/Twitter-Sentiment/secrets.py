#this file contains sensitive information like django secret key
#edit this according to your requirement

class Django_Secrets:
    def __init__(self):
        self.key = 'hf_!!6!f6n3*s7rdst(iibm-i^12d9(9d%qf%8&(jd_7sxabxi'


class Oauth_Secrets:
    def __init__(self):
        self.consumer_key = "iXZyChJoFTYpsJl765BUn3F4o"
        self.consumer_secret = "BZZ5gasUplbBTsmNjwQVv52xrnl41aMg94gRkqAAJ5fcu95daa"
        self.access_token = "844192291640160258-1LkUPnuMD4AUHApMJ1bKxVsPYYbKQrJ"
        self.access_token_secret = "ZThu9UaQsRSAsjaz5QdhVQyqbPjSUM9c8ArO7rnyA7MmS"
