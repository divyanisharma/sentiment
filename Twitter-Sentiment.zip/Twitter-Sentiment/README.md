**The app is live at [http://twittersentimeter.herokuapp.com/](http://twittersentimeter.herokuapp.com/)**
![alt text](https://cloud.githubusercontent.com/assets/17525730/20768068/8abc6fba-b762-11e6-89fd-38f75012e55e.png "Screenshot")

**Will update Readme after december with step by step Guide**
----------
### To test on local machine :-
 1. Create a Virtual environment and install the dependencies `pip install -r requirements.txt`
 2. Fill the Details in `secrets.py.template` file and save it as `secrets.py`
 3. Run django server `python manage.py runserver`
